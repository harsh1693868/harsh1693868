"""
Streamlit demo app for the Retail Product Image Classifier.

Run with (from the project root):
    streamlit run app/streamlit_app.py
"""

import sys
import os

sys.path.append(os.path.join(os.path.dirname(__file__), "..", "src"))

import streamlit as st
import torch
import numpy as np
from PIL import Image
from torchvision import transforms

from model import RetailImageClassifier
from grad_cam import GradCAM, overlay_heatmap

CLASS_NAMES = [
    "T-shirt/top", "Trouser", "Pullover", "Dress", "Coat",
    "Sandal", "Shirt", "Sneaker", "Bag", "Ankle boot",
]

st.set_page_config(page_title="Retail Product Image Classifier", layout="centered")
st.title("👕 Retail Product Image Classifier")
st.write(
    "Upload a clothing/accessory image and get a category prediction, "
    "along with a Grad-CAM heatmap showing what the model focused on."
)


@st.cache_resource
def load_model():
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = RetailImageClassifier(num_classes=len(CLASS_NAMES))
    model.load_state_dict(torch.load("checkpoints/model.pth", map_location=device))
    model.to(device)
    model.eval()
    return model, device


transform = transforms.Compose([
    transforms.Grayscale(num_output_channels=3),
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
])

uploaded_file = st.file_uploader("Upload an image", type=["jpg", "jpeg", "png"])

if uploaded_file is not None:
    model, device = load_model()

    image = Image.open(uploaded_file).convert("RGB")
    st.image(image, caption="Uploaded image", width=250)

    input_tensor = transform(image).unsqueeze(0).to(device)

    cam_extractor = GradCAM(model, target_layer=model.backbone.layer4[-1])
    cam, class_idx = cam_extractor.generate(input_tensor)

    probs = torch.softmax(model(input_tensor), dim=1).detach().cpu().numpy()[0]

    st.subheader(f"Prediction: **{CLASS_NAMES[class_idx]}** ({probs[class_idx]*100:.1f}% confidence)")

    resized_image = np.array(image.resize((224, 224)))
    overlay = overlay_heatmap(resized_image, cam)
    st.image(overlay, caption="Grad-CAM: what the model focused on", width=250)

    st.bar_chart({CLASS_NAMES[i]: float(probs[i]) for i in range(len(CLASS_NAMES))})
else:
    st.info("Upload an image to get started.")
