"""
Model definition: a ResNet18 backbone (pretrained on ImageNet) fine-tuned
for retail product image classification.

Training strategy:
1. Freeze the backbone, train only the new classification head.
2. After a few epochs, unfreeze the last residual block for fine-tuning
   at a lower learning rate. This is a standard transfer-learning recipe
   that trains fast while still adapting to the new domain.
"""

import torch.nn as nn
from torchvision import models


class RetailImageClassifier(nn.Module):
    def __init__(self, num_classes=10, freeze_backbone=True):
        super().__init__()
        self.backbone = models.resnet18(weights=models.ResNet18_Weights.IMAGENET1K_V1)

        if freeze_backbone:
            for param in self.backbone.parameters():
                param.requires_grad = False

        in_features = self.backbone.fc.in_features
        self.backbone.fc = nn.Linear(in_features, num_classes)

    def forward(self, x):
        return self.backbone(x)

    def unfreeze_last_block(self):
        """Unfreeze layer4 + fc for fine-tuning."""
        for param in self.backbone.layer4.parameters():
            param.requires_grad = True
        for param in self.backbone.fc.parameters():
            param.requires_grad = True


if __name__ == "__main__":
    import torch

    model = RetailImageClassifier(num_classes=10)
    dummy_input = torch.randn(2, 3, 224, 224)
    output = model(dummy_input)
    print(f"Output shape: {output.shape}")
