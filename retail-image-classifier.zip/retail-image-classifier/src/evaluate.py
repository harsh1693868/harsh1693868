"""
Evaluation script: loads a trained checkpoint and produces a classification
report + confusion matrix heatmap.

Run with:
    python src/evaluate.py
"""

import torch
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix, classification_report

from data_loader import get_dataloaders
from model import RetailImageClassifier


def run_evaluation(checkpoint_path="checkpoints/model.pth", device=None):
    device = device or ("cuda" if torch.cuda.is_available() else "cpu")
    _, test_loader, class_names = get_dataloaders()

    model = RetailImageClassifier(num_classes=len(class_names)).to(device)
    model.load_state_dict(torch.load(checkpoint_path, map_location=device))
    model.eval()

    all_preds, all_labels = [], []
    with torch.no_grad():
        for images, labels in test_loader:
            images = images.to(device)
            outputs = model(images)
            _, preds = outputs.max(1)
            all_preds.extend(preds.cpu().numpy())
            all_labels.extend(labels.numpy())

    print(classification_report(all_labels, all_preds, target_names=class_names))

    cm = confusion_matrix(all_labels, all_preds)
    plt.figure(figsize=(8, 6))
    sns.heatmap(
        cm, annot=True, fmt="d",
        xticklabels=class_names, yticklabels=class_names, cmap="Blues"
    )
    plt.xlabel("Predicted")
    plt.ylabel("Actual")
    plt.title("Confusion Matrix")
    plt.tight_layout()
    plt.savefig("results/confusion_matrix.png")
    print("Saved confusion matrix to results/confusion_matrix.png")


if __name__ == "__main__":
    run_evaluation()
