"""
Data loading and preprocessing for the Retail Product Image Classifier.

Uses Fashion-MNIST (Zalando Research) as a stand-in for a retail/e-commerce
apparel catalog. Images are converted to 3-channel and resized to 224x224
so they can be fed into an ImageNet-pretrained backbone (ResNet18).
"""

import torch
from torchvision import datasets, transforms
from torch.utils.data import DataLoader

CLASS_NAMES = [
    "T-shirt/top", "Trouser", "Pullover", "Dress", "Coat",
    "Sandal", "Shirt", "Sneaker", "Bag", "Ankle boot",
]


def get_dataloaders(data_dir="./data", batch_size=64, img_size=224, num_workers=2):
    """Return train/test DataLoaders and the list of class names."""

    train_transform = transforms.Compose([
        transforms.Grayscale(num_output_channels=3),
        transforms.Resize((img_size, img_size)),
        transforms.RandomHorizontalFlip(),
        transforms.RandomRotation(10),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    ])

    test_transform = transforms.Compose([
        transforms.Grayscale(num_output_channels=3),
        transforms.Resize((img_size, img_size)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    ])

    train_set = datasets.FashionMNIST(
        root=data_dir, train=True, download=True, transform=train_transform
    )
    test_set = datasets.FashionMNIST(
        root=data_dir, train=False, download=True, transform=test_transform
    )

    train_loader = DataLoader(
        train_set, batch_size=batch_size, shuffle=True, num_workers=num_workers
    )
    test_loader = DataLoader(
        test_set, batch_size=batch_size, shuffle=False, num_workers=num_workers
    )

    return train_loader, test_loader, CLASS_NAMES


if __name__ == "__main__":
    train_loader, test_loader, class_names = get_dataloaders()
    print(f"Classes: {class_names}")
    print(f"Train batches: {len(train_loader)}, Test batches: {len(test_loader)}")
