# Retail Product Image Classifier with Explainable AI (Grad-CAM)

An end-to-end deep learning project that classifies retail/apparel product
images into 10 categories using transfer learning (ResNet18), with a
Grad-CAM explainability layer and a deployed Streamlit demo app.

## Why this project

Most beginner CV projects stop at "trained a model, got X% accuracy."
This one goes further:
- **Transfer learning**, not training from scratch — the realistic industry approach.
- **Explainability (Grad-CAM)** — shows *why* the model made a prediction, which matters for any business/analytics stakeholder audience.
- **Deployment** — a working demo, not just a notebook.

This bridges a Business Analytics / Data Analyst skill set (interpretability,
stakeholder-facing outputs) with applied deep learning — useful positioning
if you're targeting Data Analyst / ML-adjacent roles.

## Project structure

```
retail-image-classifier/
├── src/
│   ├── data_loader.py     # Dataset + transforms
│   ├── model.py            # ResNet18 transfer-learning model
│   ├── train.py             # Training loop with fine-tuning schedule
│   ├── evaluate.py         # Confusion matrix + classification report
│   └── grad_cam.py         # Grad-CAM explainability
├── app/
│   └── streamlit_app.py    # Deployed demo app
├── notebooks/               # (optional) EDA / experimentation
├── results/                 # Training curves, confusion matrix (generated)
├── checkpoints/             # Saved model weights (generated)
├── requirements.txt
└── README.md
```

## Dataset

[Fashion-MNIST](https://github.com/zalandoresearch/fashion-mnist) (Zalando
Research) — 70,000 grayscale images across 10 apparel categories
(T-shirt/top, Trouser, Pullover, Dress, Coat, Sandal, Shirt, Sneaker, Bag,
Ankle boot). Auto-downloads via `torchvision` on first run.

## Setup (in VS Code)

1. Open this folder in VS Code.
2. Create a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate      # Windows: venv\Scripts\activate
   ```
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. (Optional but recommended) In VS Code, select the `venv` interpreter:
   `Ctrl+Shift+P` → "Python: Select Interpreter" → choose `venv`.

## Running the project

**Train the model** (from the project root):
```bash
cd src
python train.py
```
This downloads Fashion-MNIST automatically, fine-tunes ResNet18, and saves:
- `checkpoints/model.pth`
- `results/training_curves.png`

Expect ~91-93% test accuracy after 10 epochs on CPU (faster with GPU).

**Evaluate the model:**
```bash
python evaluate.py
```
Produces `results/confusion_matrix.png` and a classification report in the terminal.

**Run the live demo app:**
```bash
cd ..
streamlit run app/streamlit_app.py
```
Upload any clothing/accessory image and see the prediction + Grad-CAM heatmap.

## Deployment

To make this a **live, shareable link** (important for your resume/LinkedIn):

**Option A — Streamlit Community Cloud (easiest, free):**
1. Push this project to a public GitHub repo.
2. Go to [share.streamlit.io](https://share.streamlit.io), connect your GitHub, and deploy `app/streamlit_app.py`.
3. You'll get a public URL like `https://your-app.streamlit.app`.

**Option B — Hugging Face Spaces:**
1. Create a new Space (SDK: Streamlit).
2. Push this repo's contents to the Space.
3. Get a public URL under `huggingface.co/spaces/...`.

Include `checkpoints/model.pth` in the repo (or use Git LFS if it's large)
so the deployed app can load it.

## Results (fill in after training)

| Metric | Value |
|---|---|
| Test Accuracy | ~92% |
| Test Loss | — |
| Best epoch | — |

(Replace with your actual numbers — screenshots of `results/training_curves.png`
and `results/confusion_matrix.png` are great to attach to your resume/portfolio.)

## Resume bullet points (ready to use)

- Built and deployed an end-to-end image classification pipeline (PyTorch,
  ResNet18 transfer learning) achieving ~92% accuracy on a 10-class apparel
  dataset, including a Grad-CAM explainability layer to visualize model decisions.
- Designed a modular ML codebase (data loading, training, evaluation,
  explainability) and deployed a live Streamlit demo app for stakeholder-facing
  predictions.
- Applied transfer learning and fine-tuning strategies to reduce training time
  while maintaining high classification accuracy on limited compute.

## LinkedIn post draft

> Just wrapped up a project I'm excited about: an end-to-end **image
> classification pipeline** built with **PyTorch**, going beyond "train
> a model" to include explainability and deployment.
>
> 🔹 Transfer learning with ResNet18 for retail/apparel product classification
> 🔹 Grad-CAM heatmaps to visualize *why* the model predicts what it predicts
> 🔹 Deployed as a live Streamlit app — try uploading an image and see the model's reasoning in real time
>
> Coming from a Business Analytics background, what excited me most was the
> explainability piece — it's the layer that turns a "black box" model into
> something a business stakeholder can actually trust and act on.
>
> Live demo: [your Streamlit link]
> Code: [your GitHub link]
>
> #PyTorch #MachineLearning #DataAnalytics #ComputerVision #DeepLearning
