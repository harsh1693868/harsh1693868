"""
Loads results/pytorch_metrics.json and results/tensorflow_metrics.json
(produced by pytorch_cnn.py and tensorflow_cnn.py) and generates:

    results/comparison.png        - accuracy/loss curves side by side
    results/comparison_table.md   - markdown table for the README

Run this after training both models:
    python src/compare_results.py
"""

import json
import os

import matplotlib.pyplot as plt

from model_utils import RESULTS_DIR


def load_metrics(framework: str) -> dict:
    path = os.path.join(RESULTS_DIR, f"{framework}_metrics.json")
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"{path} not found. Run src/{framework}_cnn.py first."
        )
    with open(path) as f:
        return json.load(f)


def plot_comparison(pt: dict, tf_: dict):
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))

    axes[0].plot(pt["history"]["val_acc"], label="PyTorch")
    axes[0].plot(tf_["history"]["val_acc"], label="TensorFlow")
    axes[0].set_title("Validation Accuracy per Epoch")
    axes[0].set_xlabel("Epoch")
    axes[0].set_ylabel("Accuracy")
    axes[0].legend()
    axes[0].grid(alpha=0.3)

    axes[1].plot(pt["history"]["val_loss"], label="PyTorch")
    axes[1].plot(tf_["history"]["val_loss"], label="TensorFlow")
    axes[1].set_title("Validation Loss per Epoch")
    axes[1].set_xlabel("Epoch")
    axes[1].set_ylabel("Loss")
    axes[1].legend()
    axes[1].grid(alpha=0.3)

    fig.suptitle("PyTorch vs TensorFlow — CIFAR-10 CNN Benchmark")
    fig.tight_layout()
    out_path = os.path.join(RESULTS_DIR, "comparison.png")
    fig.savefig(out_path, dpi=150)
    print(f"Saved plot to {out_path}")


def write_table(pt: dict, tf_: dict):
    lines = [
        "| Metric              | PyTorch | TensorFlow |",
        "|----------------------|---------|------------|",
        f"| Test Accuracy       | {pt['final_test_accuracy']:.4f} | {tf_['final_test_accuracy']:.4f} |",
        f"| Test Loss           | {pt['final_test_loss']:.4f} | {tf_['final_test_loss']:.4f} |",
        f"| Avg. Epoch Time (s) | {pt['avg_epoch_time_sec']:.1f} | {tf_['avg_epoch_time_sec']:.1f} |",
        f"| Total Parameters    | {pt['total_parameters']:,} | {tf_['total_parameters']:,} |",
    ]
    out_path = os.path.join(RESULTS_DIR, "comparison_table.md")
    with open(out_path, "w") as f:
        f.write("\n".join(lines) + "\n")
    print(f"Saved table to {out_path}")
    print("\n".join(lines))


if __name__ == "__main__":
    pt_metrics = load_metrics("pytorch")
    tf_metrics = load_metrics("tensorflow")
    plot_comparison(pt_metrics, tf_metrics)
    write_table(pt_metrics, tf_metrics)
