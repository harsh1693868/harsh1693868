"""Shared constants used by both the PyTorch and TensorFlow pipelines.

Keeping these identical across both scripts is what makes the benchmark
comparison fair -- same classes, same input shape, same default
hyperparameters unless overridden via CLI args.
"""

CLASSES = [
    "airplane",
    "automobile",
    "bird",
    "cat",
    "deer",
    "dog",
    "frog",
    "horse",
    "ship",
    "truck",
]

NUM_CLASSES = len(CLASSES)
INPUT_SHAPE = (32, 32, 3)  # H, W, C (CIFAR-10 native size)

DEFAULT_EPOCHS = 15
DEFAULT_BATCH_SIZE = 64
DEFAULT_LR = 0.001

RESULTS_DIR = "results"
