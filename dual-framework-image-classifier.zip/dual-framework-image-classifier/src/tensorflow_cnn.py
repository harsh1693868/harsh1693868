"""
TensorFlow/Keras CNN image classifier trained on CIFAR-10.
Mirrors the architecture and hyperparameters of src/pytorch_cnn.py so the two
frameworks can be fairly compared.

Usage:
    python src/tensorflow_cnn.py --epochs 15 --batch-size 64 --lr 0.001

Saves:
    results/tensorflow_metrics.json
    results/tensorflow_model.keras
"""

import argparse
import json
import os
import time

import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, models

from model_utils import (
    DEFAULT_BATCH_SIZE,
    DEFAULT_EPOCHS,
    DEFAULT_LR,
    INPUT_SHAPE,
    NUM_CLASSES,
    RESULTS_DIR,
)


def build_model(input_shape=INPUT_SHAPE, num_classes=NUM_CLASSES):
    """Same architecture described in the README, implemented in Keras."""
    model = models.Sequential(
        [
            layers.Input(shape=input_shape),
            layers.Conv2D(32, 3, padding="same", activation="relu"),
            layers.BatchNormalization(),
            layers.MaxPooling2D(2),
            layers.Conv2D(64, 3, padding="same", activation="relu"),
            layers.BatchNormalization(),
            layers.MaxPooling2D(2),
            layers.Conv2D(128, 3, padding="same", activation="relu"),
            layers.BatchNormalization(),
            layers.MaxPooling2D(2),
            layers.Flatten(),
            layers.Dropout(0.4),
            layers.Dense(256, activation="relu"),
            layers.Dense(num_classes, activation="softmax"),
        ]
    )
    return model


def get_datasets(batch_size):
    (x_train, y_train), (x_test, y_test) = tf.keras.datasets.cifar10.load_data()
    x_train = x_train.astype("float32") / 255.0
    x_test = x_test.astype("float32") / 255.0
    y_train = y_train.flatten()
    y_test = y_test.flatten()

    mean = np.array([0.4914, 0.4822, 0.4465])
    std = np.array([0.2470, 0.2435, 0.2616])
    x_train = (x_train - mean) / std
    x_test = (x_test - mean) / std

    train_ds = tf.data.Dataset.from_tensor_slices((x_train, y_train))
    train_ds = train_ds.shuffle(50000).batch(batch_size).prefetch(tf.data.AUTOTUNE)

    test_ds = tf.data.Dataset.from_tensor_slices((x_test, y_test))
    test_ds = test_ds.batch(batch_size).prefetch(tf.data.AUTOTUNE)

    return train_ds, test_ds


class EpochTimer(tf.keras.callbacks.Callback):
    def __init__(self):
        super().__init__()
        self.times = []

    def on_epoch_begin(self, epoch, logs=None):
        self._start = time.time()

    def on_epoch_end(self, epoch, logs=None):
        self.times.append(time.time() - self._start)


def train(args):
    gpus = tf.config.list_physical_devices("GPU")
    print(f"Using device: {'GPU' if gpus else 'CPU'}")

    train_ds, test_ds = get_datasets(args.batch_size)

    model = build_model()
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=args.lr),
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"],
    )

    timer = EpochTimer()
    history = model.fit(
        train_ds,
        validation_data=test_ds,
        epochs=args.epochs,
        callbacks=[timer],
        verbose=2,
    )

    test_loss, test_acc = model.evaluate(test_ds, verbose=0)

    os.makedirs(RESULTS_DIR, exist_ok=True)
    total_params = model.count_params()

    metrics = {
        "framework": "TensorFlow",
        "final_test_loss": float(test_loss),
        "final_test_accuracy": float(test_acc),
        "avg_epoch_time_sec": float(np.mean(timer.times)),
        "total_parameters": int(total_params),
        "history": {
            "train_loss": [float(v) for v in history.history["loss"]],
            "train_acc": [float(v) for v in history.history["accuracy"]],
            "val_loss": [float(v) for v in history.history["val_loss"]],
            "val_acc": [float(v) for v in history.history["val_accuracy"]],
        },
    }

    with open(os.path.join(RESULTS_DIR, "tensorflow_metrics.json"), "w") as f:
        json.dump(metrics, f, indent=2)

    model.save(os.path.join(RESULTS_DIR, "tensorflow_model.keras"))
    print("Saved metrics to results/tensorflow_metrics.json")
    print("Saved model to results/tensorflow_model.keras")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Train a CNN on CIFAR-10 with TensorFlow/Keras"
    )
    parser.add_argument("--epochs", type=int, default=DEFAULT_EPOCHS)
    parser.add_argument("--batch-size", type=int, default=DEFAULT_BATCH_SIZE)
    parser.add_argument("--lr", type=float, default=DEFAULT_LR)
    train(parser.parse_args())
