# Dual-Framework Image Classifier: PyTorch vs TensorFlow

A side-by-side implementation of the same Convolutional Neural Network (CNN) image
classification task — once in **PyTorch** and once in **TensorFlow / Keras** — trained
and evaluated on the **CIFAR-10** dataset. The project demonstrates the ability to work
across both major deep learning frameworks, compares their training behavior, and
produces a reproducible benchmark report.

## Why this project

Most portfolios show a single framework. This project intentionally implements the
**same architecture, same hyperparameters, same data pipeline** in both PyTorch and
TensorFlow so the two can be fairly compared on:

- Training time per epoch
- Final test accuracy / loss
- Convergence behavior (loss & accuracy curves)
- Code ergonomics (imperative vs. graph-based style)

## Project structure

```
dual-framework-image-classifier/
├── README.md
├── requirements.txt
├── .gitignore
├── LICENSE
├── src/
│   ├── pytorch_cnn.py         # PyTorch training + evaluation pipeline
│   ├── tensorflow_cnn.py      # TensorFlow/Keras training + evaluation pipeline
│   ├── model_utils.py         # Shared constants (classes, hyperparameters)
│   └── compare_results.py     # Generates side-by-side comparison plots/table
├── results/                   # Metrics + plots written here after training
└── .github/workflows/
    └── ci.yml                 # Basic CI: lints and smoke-tests both scripts
```

## Model architecture (identical in both frameworks)

```
Conv2D(32) -> ReLU -> BatchNorm -> MaxPool
Conv2D(64) -> ReLU -> BatchNorm -> MaxPool
Conv2D(128) -> ReLU -> BatchNorm -> MaxPool
Flatten -> Dropout(0.4) -> Dense(256) -> ReLU -> Dense(10, softmax)
```

## Setup

```bash
git clone https://github.com/<your-username>/dual-framework-image-classifier.git
cd dual-framework-image-classifier
python -m venv venv
source venv/bin/activate      # On Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## Usage

Train and evaluate the PyTorch model:

```bash
python src/pytorch_cnn.py --epochs 15 --batch-size 64 --lr 0.001
```

Train and evaluate the TensorFlow model:

```bash
python src/tensorflow_cnn.py --epochs 15 --batch-size 64 --lr 0.001
```

Both scripts save metrics to `results/pytorch_metrics.json` and
`results/tensorflow_metrics.json` respectively, plus the trained model weights.

Generate the side-by-side comparison chart and markdown table once both have run:

```bash
python src/compare_results.py
```

This writes `results/comparison.png` and `results/comparison_table.md`.

## Results

*(Fill in after running training — this keeps the README honest and reproducible
rather than reporting numbers that weren't actually measured on your machine.)*

| Metric              | PyTorch | TensorFlow |
|---------------------|---------|------------|
| Test Accuracy       |   TBD   |    TBD     |
| Test Loss           |   TBD   |    TBD     |
| Avg. Epoch Time (s) |   TBD   |    TBD     |
| Total Parameters    |   TBD   |    TBD     |

## Tech stack

- Python 3.10+
- PyTorch, torchvision
- TensorFlow / Keras
- NumPy, Matplotlib
- CIFAR-10 (auto-downloaded by both frameworks' dataset utilities)

## Possible extensions

- Add Grad-CAM explainability for both models (see my related project:
  *Retail Product Image Classifier with Explainable AI*)
- Swap CIFAR-10 for a custom retail/product dataset
- Add mixed-precision training comparison
- Deploy both models behind a Streamlit demo with a framework toggle

## License

MIT — see [LICENSE](LICENSE).
