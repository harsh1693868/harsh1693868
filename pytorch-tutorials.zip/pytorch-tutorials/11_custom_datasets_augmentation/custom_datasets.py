"""
11 - Custom Datasets & Data Augmentation
===========================================
Shows how to write a Dataset class for your OWN image files on disk (the
pattern you'll use for any real-world image project), plus how to apply
data augmentation with torchvision.transforms to improve generalization.

This script generates a small set of synthetic images on disk so it's fully
self-contained and runnable without any external data.

Run this file: python 11_custom_datasets_augmentation/custom_datasets.py
"""

import os
import torch
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
from PIL import Image
import numpy as np


def section(title):
    print("\n" + "=" * 60)
    print(title)
    print("=" * 60)


# ---------------------------------------------------------------------------
# 0. Generate a tiny synthetic image dataset on disk (so this script is
#    fully self-contained -- in a real project, this is where your own
#    images already live)
# ---------------------------------------------------------------------------
section("0. Generating a Synthetic Image Dataset")

DATA_DIR = "./data/synthetic_images"
CLASSES = ["red_squares", "blue_circles"]

os.makedirs(DATA_DIR, exist_ok=True)
for cls in CLASSES:
    os.makedirs(os.path.join(DATA_DIR, cls), exist_ok=True)

rng = np.random.default_rng(0)


def make_red_square(path):
    arr = np.zeros((64, 64, 3), dtype=np.uint8)
    arr[16:48, 16:48, 0] = 255   # red square in the middle
    arr += rng.integers(0, 20, size=arr.shape, dtype=np.uint8)  # slight noise
    Image.fromarray(arr).save(path)


def make_blue_circle(path):
    arr = np.zeros((64, 64, 3), dtype=np.uint8)
    yy, xx = np.ogrid[:64, :64]
    mask = (xx - 32) ** 2 + (yy - 32) ** 2 <= 20 ** 2
    arr[mask, 2] = 255   # blue circle
    arr += rng.integers(0, 20, size=arr.shape, dtype=np.uint8)
    Image.fromarray(arr).save(path)


n_per_class = 20
for i in range(n_per_class):
    make_red_square(os.path.join(DATA_DIR, "red_squares", f"img_{i}.png"))
    make_blue_circle(os.path.join(DATA_DIR, "blue_circles", f"img_{i}.png"))

print(f"Generated {n_per_class} images per class in {DATA_DIR}")


# ---------------------------------------------------------------------------
# 1. Custom Dataset that reads images from a folder structure
# ---------------------------------------------------------------------------
section("1. Custom Image Dataset")


class ImageFolderDataset(Dataset):
    """
    A minimal re-implementation of the idea behind torchvision's
    ImageFolder: expects a directory structure like

        root/
          class_a/
            img1.png
            img2.png
          class_b/
            img3.png
            ...

    and produces (image_tensor, label_index) pairs.
    """

    def __init__(self, root, transform=None):
        self.root = root
        self.transform = transform
        self.classes = sorted(os.listdir(root))
        self.class_to_idx = {cls: i for i, cls in enumerate(self.classes)}

        self.samples = []   # list of (filepath, label_idx)
        for cls in self.classes:
            cls_dir = os.path.join(root, cls)
            for fname in os.listdir(cls_dir):
                self.samples.append((os.path.join(cls_dir, fname), self.class_to_idx[cls]))

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        filepath, label = self.samples[idx]
        image = Image.open(filepath).convert("RGB")

        if self.transform:
            image = self.transform(image)

        return image, label


# ---------------------------------------------------------------------------
# 2. Data augmentation with torchvision.transforms
# ---------------------------------------------------------------------------
section("2. Data Augmentation")

# Augmentation pipeline typically used for TRAINING -- introduces variety so
# the model doesn't memorize exact pixel positions/orientations.
train_transform = transforms.Compose([
    transforms.RandomHorizontalFlip(p=0.5),
    transforms.RandomRotation(degrees=15),
    transforms.ColorJitter(brightness=0.2, contrast=0.2),
    transforms.ToTensor(),
    transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5)),
])

# Validation/test transform: NO random augmentation, just consistent preprocessing
eval_transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5)),
])

train_dataset = ImageFolderDataset(DATA_DIR, transform=train_transform)
eval_dataset = ImageFolderDataset(DATA_DIR, transform=eval_transform)

print("Classes found:", train_dataset.classes)
print("Class-to-index mapping:", train_dataset.class_to_idx)
print("Total images:", len(train_dataset))

train_loader = DataLoader(train_dataset, batch_size=8, shuffle=True)
batch_images, batch_labels = next(iter(train_loader))
print("Batch of augmented images shape:", batch_images.shape)
print("Batch labels:", batch_labels)


# ---------------------------------------------------------------------------
# 3. Visualizing the effect of augmentation (saves a comparison image)
# ---------------------------------------------------------------------------
section("3. Visualizing Augmentation Effects")

sample_path = train_dataset.samples[0][0]
original_image = Image.open(sample_path).convert("RGB")

augmented_versions = [train_transform(original_image) for _ in range(4)]


def tensor_to_pil(t):
    # Undo normalization for viewing purposes
    t = t * 0.5 + 0.5
    arr = (t.permute(1, 2, 0).numpy() * 255).astype(np.uint8)
    return Image.fromarray(arr)


out_path = "./data/augmentation_preview.png"
canvas = Image.new("RGB", (64 * 5, 64))
canvas.paste(original_image.resize((64, 64)), (0, 0))
for i, aug in enumerate(augmented_versions):
    canvas.paste(tensor_to_pil(aug), (64 * (i + 1), 0))
canvas.save(out_path)
print(f"Saved a side-by-side preview (original + 4 augmented versions) to {out_path}")


if __name__ == "__main__":
    print("\nIn a real project, point ImageFolderDataset (or torchvision's")
    print("built-in datasets.ImageFolder) at your own labeled image directory.")
    print("Apply augmentation to the TRAINING set only -- never to validation/test.")
