"""
01 - Tensors
============
Tensors are the fundamental data structure in PyTorch — similar to NumPy arrays,
but with two superpowers: they can run on a GPU, and they support automatic
differentiation (covered in module 02).

Run this file: python 01_tensors/tensors.py
"""

import torch
import numpy as np


def section(title):
    print("\n" + "=" * 60)
    print(title)
    print("=" * 60)


# ---------------------------------------------------------------------------
# 1. Creating tensors
# ---------------------------------------------------------------------------
section("1. Creating Tensors")

# From a Python list
t_list = torch.tensor([1, 2, 3, 4])
print("From list:", t_list)

# From a NumPy array
np_array = np.array([1.0, 2.0, 3.0])
t_numpy = torch.from_numpy(np_array)
print("From NumPy:", t_numpy)

# Filled with zeros / ones / random values
zeros = torch.zeros(2, 3)
ones = torch.ones(2, 3)
rand = torch.rand(2, 3)          # uniform [0, 1)
randn = torch.randn(2, 3)        # standard normal
print("Zeros:\n", zeros)
print("Ones:\n", ones)
print("Random (uniform):\n", rand)
print("Random (normal):\n", randn)

# Like another tensor's shape
like_zeros = torch.zeros_like(rand)
print("Zeros with same shape as `rand`:\n", like_zeros)


# ---------------------------------------------------------------------------
# 2. Shape, dtype, and device
# ---------------------------------------------------------------------------
section("2. Shape, Dtype, Device")

t = torch.rand(3, 4)
print("Shape:", t.shape)
print("Number of dimensions:", t.ndim)
print("Dtype:", t.dtype)
print("Device:", t.device)

# Casting dtype
t_int = t.to(torch.int32)
print("Cast to int32:\n", t_int)


# ---------------------------------------------------------------------------
# 3. Indexing and slicing (NumPy-style)
# ---------------------------------------------------------------------------
section("3. Indexing & Slicing")

t = torch.arange(12).reshape(3, 4)
print("Original tensor:\n", t)
print("First row:", t[0])
print("Last column:", t[:, -1])
print("Sub-matrix (rows 0-1, cols 1-2):\n", t[0:2, 1:3])


# ---------------------------------------------------------------------------
# 4. Reshaping
# ---------------------------------------------------------------------------
section("4. Reshaping")

t = torch.arange(12)
print("Original:", t)
print("Reshaped to (3, 4):\n", t.reshape(3, 4))
print("Reshaped to (4, 3):\n", t.reshape(4, 3))
print("Flattened again:", t.reshape(3, 4).flatten())

# view() vs reshape(): view requires contiguous memory, reshape handles it for you
print("Using view():\n", t.view(2, 6))


# ---------------------------------------------------------------------------
# 5. Basic operations & broadcasting
# ---------------------------------------------------------------------------
section("5. Operations & Broadcasting")

a = torch.tensor([[1, 2, 3], [4, 5, 6]])
b = torch.tensor([10, 20, 30])   # shape (3,) broadcasts against (2, 3)

print("a + b (broadcast):\n", a + b)
print("Element-wise multiply:\n", a * 2)
print("Matrix multiply (a @ a.T):\n", a @ a.T)
print("Sum all elements:", a.sum().item())
print("Sum along dim 0 (columns):", a.sum(dim=0))
print("Sum along dim 1 (rows):", a.sum(dim=1))
print("Mean (as float):", a.float().mean().item())


# ---------------------------------------------------------------------------
# 6. Tensor <-> NumPy interop
# ---------------------------------------------------------------------------
section("6. Tensor <-> NumPy")

t = torch.ones(3)
np_from_t = t.numpy()
print("Tensor:", t, "-> NumPy:", np_from_t)

# IMPORTANT: on CPU, these share memory! Modifying one modifies the other.
t.add_(1)
print("After t.add_(1), NumPy array also changed:", np_from_t)


if __name__ == "__main__":
    print("\nAll tensor basics demonstrated. Try modifying shapes/values above!")
