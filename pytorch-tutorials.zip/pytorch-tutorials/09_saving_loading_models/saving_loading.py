"""
09 - Saving & Loading Models
===============================
Covers the standard PyTorch patterns for checkpointing: saving/loading just
the weights (state_dict), saving full training checkpoints for resuming, and
exporting a model for inference.

Run this file: python 09_saving_loading_models/saving_loading.py
"""

import os
import torch
import torch.nn as nn


def section(title):
    print("\n" + "=" * 60)
    print(title)
    print("=" * 60)


os.makedirs("./checkpoints", exist_ok=True)


class SmallNet(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(10, 32)
        self.fc2 = nn.Linear(32, 2)

    def forward(self, x):
        return self.fc2(torch.relu(self.fc1(x)))


# ---------------------------------------------------------------------------
# 1. Saving & loading just the weights (recommended approach)
# ---------------------------------------------------------------------------
section("1. state_dict — the recommended way")

model = SmallNet()
print("Original fc1 weight (first 3 values):", model.fc1.weight[0][:3])

# state_dict() is an ordered dict mapping layer names -> tensors
weights_path = "./checkpoints/model_weights.pth"
torch.save(model.state_dict(), weights_path)
print(f"Saved weights to {weights_path}")

# To load: you must first instantiate the SAME model architecture,
# then load the saved weights into it.
loaded_model = SmallNet()
loaded_model.load_state_dict(torch.load(weights_path, weights_only=True))
loaded_model.eval()   # set to eval mode for inference (disables dropout etc.)

print("Loaded fc1 weight (first 3 values): ", loaded_model.fc1.weight[0][:3])
print("Weights match:", torch.equal(model.fc1.weight, loaded_model.fc1.weight))


# ---------------------------------------------------------------------------
# 2. Full training checkpoints (model + optimizer + epoch) — for resuming
# ---------------------------------------------------------------------------
section("2. Full Checkpoints (for resuming training)")

optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)

checkpoint = {
    "epoch": 12,
    "model_state_dict": model.state_dict(),
    "optimizer_state_dict": optimizer.state_dict(),
    "loss": 0.234,
}

checkpoint_path = "./checkpoints/training_checkpoint.pth"
torch.save(checkpoint, checkpoint_path)
print(f"Saved full checkpoint to {checkpoint_path}")

# Resuming: recreate model + optimizer, then restore their states
resumed_model = SmallNet()
resumed_optimizer = torch.optim.Adam(resumed_model.parameters(), lr=1e-3)

loaded_checkpoint = torch.load(checkpoint_path, weights_only=False)
resumed_model.load_state_dict(loaded_checkpoint["model_state_dict"])
resumed_optimizer.load_state_dict(loaded_checkpoint["optimizer_state_dict"])
start_epoch = loaded_checkpoint["epoch"] + 1

print(f"Resumed model from epoch {loaded_checkpoint['epoch']}, "
      f"continuing at epoch {start_epoch}, previous loss={loaded_checkpoint['loss']}")


# ---------------------------------------------------------------------------
# 3. Saving the entire model object (NOT recommended, but you'll see it)
# ---------------------------------------------------------------------------
section("3. Saving the Whole Model Object (use with caution)")

whole_model_path = "./checkpoints/whole_model.pth"
torch.save(model, whole_model_path)   # pickles the entire object, including class definition

# This only works if the SmallNet class definition is importable/available
# in whatever script loads it later -- which is why state_dict is preferred
# for portability and long-term compatibility.
loaded_whole_model = torch.load(whole_model_path, weights_only=False)
print("Loaded whole model:", loaded_whole_model)


# ---------------------------------------------------------------------------
# 4. Exporting to TorchScript for deployment / inference-only use
# ---------------------------------------------------------------------------
section("4. TorchScript Export (for deployment)")

model.eval()
example_input = torch.randn(1, 10)
traced_model = torch.jit.trace(model, example_input)

torchscript_path = "./checkpoints/model_traced.pt"
traced_model.save(torchscript_path)
print(f"Saved TorchScript model to {torchscript_path}")

# TorchScript models can be loaded WITHOUT the original Python class definition
loaded_traced = torch.jit.load(torchscript_path)
print("TorchScript output matches original:",
      torch.allclose(loaded_traced(example_input), model(example_input)))


if __name__ == "__main__":
    print("\nRule of thumb:")
    print("  - Use state_dict() for everyday saving/loading of your own models.")
    print("  - Use a full checkpoint dict when you need to RESUME training.")
    print("  - Use TorchScript (or ONNX) when exporting for production/deployment.")
