"""
02 - Autograd (Automatic Differentiation)
==========================================
PyTorch's autograd engine automatically computes gradients for tensor operations.
This is the backbone of training neural networks via backpropagation.

Run this file: python 02_autograd/autograd.py
"""

import torch


def section(title):
    print("\n" + "=" * 60)
    print(title)
    print("=" * 60)


# ---------------------------------------------------------------------------
# 1. requires_grad and the computation graph
# ---------------------------------------------------------------------------
section("1. requires_grad")

x = torch.tensor(2.0, requires_grad=True)
y = x ** 2 + 3 * x + 1   # y = x^2 + 3x + 1

print("x:", x)
print("y:", y)
print("y.grad_fn:", y.grad_fn)  # shows the operation that created y

# dy/dx = 2x + 3  -> at x=2, dy/dx = 7
y.backward()
print("dy/dx at x=2:", x.grad.item(), "(expected 7.0)")


# ---------------------------------------------------------------------------
# 2. Gradients with vectors
# ---------------------------------------------------------------------------
section("2. Gradients with Vectors")

x = torch.tensor([1.0, 2.0, 3.0], requires_grad=True)
y = (x ** 2).sum()   # y = x1^2 + x2^2 + x3^2

y.backward()
print("x:", x)
print("dy/dx (should be 2*x):", x.grad)


# ---------------------------------------------------------------------------
# 3. Gradients accumulate — you must zero them between steps
# ---------------------------------------------------------------------------
section("3. Gradient Accumulation")

x = torch.tensor(3.0, requires_grad=True)

for step in range(3):
    y = x ** 2
    y.backward()
    print(f"Step {step}: x.grad = {x.grad.item()} (keeps accumulating!)")

# This is exactly why training loops call optimizer.zero_grad() every iteration.
x.grad.zero_()
print("After zero_(): x.grad =", x.grad.item())


# ---------------------------------------------------------------------------
# 4. Stopping gradient tracking
# ---------------------------------------------------------------------------
section("4. torch.no_grad() and .detach()")

x = torch.tensor(5.0, requires_grad=True)

with torch.no_grad():
    # Operations here are not tracked -- useful for inference / evaluation
    y = x * 2
    print("Inside no_grad, y.requires_grad:", y.requires_grad)

y_detached = (x * 2).detach()
print("Detached tensor requires_grad:", y_detached.requires_grad)


# ---------------------------------------------------------------------------
# 5. A tiny manual "training loop" using autograd (linear regression)
# ---------------------------------------------------------------------------
section("5. Manual Gradient Descent with Autograd")

torch.manual_seed(0)

# True relationship: y = 3x + 2 (+ noise)
x_data = torch.linspace(-5, 5, 100).unsqueeze(1)
y_data = 3 * x_data + 2 + torch.randn_like(x_data) * 0.5

# Parameters we want to learn
w = torch.randn(1, requires_grad=True)
b = torch.randn(1, requires_grad=True)

lr = 0.01
for epoch in range(200):
    y_pred = x_data * w + b
    loss = ((y_pred - y_data) ** 2).mean()

    loss.backward()

    # Update weights manually, without tracking this operation in the graph
    with torch.no_grad():
        w -= lr * w.grad
        b -= lr * b.grad

    # Reset gradients for the next iteration
    w.grad.zero_()
    b.grad.zero_()

    if epoch % 40 == 0:
        print(f"Epoch {epoch:3d} | loss={loss.item():.4f} | w={w.item():.3f} | b={b.item():.3f}")

print(f"\nFinal learned parameters: w={w.item():.3f}, b={b.item():.3f} (target: w=3, b=2)")


if __name__ == "__main__":
    print("\nAutograd basics demonstrated — this is exactly what nn.Module +")
    print("optimizer.step() automate for you in later modules.")
