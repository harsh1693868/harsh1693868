"""
04 - Datasets & DataLoaders
=============================
torch.utils.data.Dataset defines how to access individual samples.
torch.utils.data.DataLoader wraps a Dataset to handle batching, shuffling,
and parallel loading.

Run this file: python 04_datasets_dataloaders/datasets_dataloaders.py
"""

import torch
from torch.utils.data import Dataset, DataLoader, random_split


def section(title):
    print("\n" + "=" * 60)
    print(title)
    print("=" * 60)


# ---------------------------------------------------------------------------
# 1. A minimal custom Dataset
# ---------------------------------------------------------------------------
section("1. Custom Dataset")


class ToyDataset(Dataset):
    """Wraps a simple in-memory regression dataset: y = 2x + noise."""

    def __init__(self, n_samples=200):
        torch.manual_seed(42)
        self.x = torch.linspace(-10, 10, n_samples).unsqueeze(1)
        self.y = 2 * self.x + torch.randn_like(self.x) * 1.5

    def __len__(self):
        # Must return the total number of samples
        return len(self.x)

    def __getitem__(self, idx):
        # Must return a single (features, label) pair
        return self.x[idx], self.y[idx]


dataset = ToyDataset(n_samples=200)
print("Dataset length:", len(dataset))
print("First sample (x, y):", dataset[0])


# ---------------------------------------------------------------------------
# 2. Splitting into train / validation sets
# ---------------------------------------------------------------------------
section("2. Train / Validation Split")

train_size = int(0.8 * len(dataset))
val_size = len(dataset) - train_size
train_ds, val_ds = random_split(dataset, [train_size, val_size])
print(f"Train size: {len(train_ds)}, Val size: {len(val_ds)}")


# ---------------------------------------------------------------------------
# 3. DataLoader: batching + shuffling
# ---------------------------------------------------------------------------
section("3. DataLoader")

train_loader = DataLoader(train_ds, batch_size=16, shuffle=True)
val_loader = DataLoader(val_ds, batch_size=16, shuffle=False)

# Pull out a single batch to inspect
batch_x, batch_y = next(iter(train_loader))
print("Batch x shape:", batch_x.shape)   # (16, 1)
print("Batch y shape:", batch_y.shape)   # (16, 1)

# Iterate over all batches (this is what happens inside a training loop)
n_batches = 0
for batch_x, batch_y in train_loader:
    n_batches += 1
print(f"Total batches per epoch: {n_batches} (dataset size {len(train_ds)} / batch size 16)")


# ---------------------------------------------------------------------------
# 4. Using torchvision's built-in datasets + transforms
# ---------------------------------------------------------------------------
section("4. torchvision Datasets (preview)")

try:
    from torchvision import datasets, transforms

    transform = transforms.Compose([
        transforms.ToTensor(),                       # PIL Image -> Tensor, scales to [0, 1]
        transforms.Normalize((0.5,), (0.5,)),         # normalize to [-1, 1]
    ])

    # This downloads MNIST on first run (~10 MB). Comment out if you want to skip.
    train_mnist = datasets.MNIST(root="./data", train=True, download=True, transform=transform)
    mnist_loader = DataLoader(train_mnist, batch_size=32, shuffle=True)

    images, labels = next(iter(mnist_loader))
    print("MNIST batch of images shape:", images.shape)   # (32, 1, 28, 28)
    print("MNIST batch of labels shape:", labels.shape)
    print("Sample labels:", labels[:10])
except Exception as e:
    print("Skipping MNIST download (no internet or torchvision issue):", e)


if __name__ == "__main__":
    print("\nYou now know how to wrap data in a Dataset and feed it through a")
    print("DataLoader in mini-batches -- the standard way to feed data to a model.")
