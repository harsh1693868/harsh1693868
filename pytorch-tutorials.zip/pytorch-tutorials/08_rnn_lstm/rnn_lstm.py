"""
08 - RNN / LSTM for Sequence Data
====================================
Demonstrates sequence modeling with nn.LSTM on a synthetic task: classifying
whether a sequence of numbers is trending "up" or "down" overall. The same
pattern applies to text classification, time-series, and other sequence tasks.

Run this file: python 08_rnn_lstm/rnn_lstm.py
"""

import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader, random_split


def section(title):
    print("\n" + "=" * 60)
    print(title)
    print("=" * 60)


device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Using device:", device)


# ---------------------------------------------------------------------------
# 1. Synthetic sequence dataset
# ---------------------------------------------------------------------------
section("1. Synthetic Sequence Data")


class TrendDataset(Dataset):
    """
    Generates sequences of length `seq_len`. Label 1 = overall upward trend,
    label 0 = overall downward trend, both with added noise.
    """

    def __init__(self, n_samples=1000, seq_len=20):
        torch.manual_seed(1)
        self.seq_len = seq_len
        sequences = []
        labels = []

        for _ in range(n_samples):
            trend_up = torch.rand(1).item() > 0.5
            slope = 0.5 if trend_up else -0.5
            base = torch.linspace(0, slope * seq_len, seq_len)
            noise = torch.randn(seq_len) * 1.5
            seq = (base + noise).unsqueeze(-1)   # shape (seq_len, 1) -- 1 feature per timestep
            sequences.append(seq)
            labels.append(1 if trend_up else 0)

        self.x = torch.stack(sequences)          # (n_samples, seq_len, 1)
        self.y = torch.tensor(labels).long()

    def __len__(self):
        return len(self.x)

    def __getitem__(self, idx):
        return self.x[idx], self.y[idx]


dataset = TrendDataset(n_samples=1000, seq_len=20)
train_size = int(0.8 * len(dataset))
val_size = len(dataset) - train_size
train_ds, val_ds = random_split(dataset, [train_size, val_size])

train_loader = DataLoader(train_ds, batch_size=32, shuffle=True)
val_loader = DataLoader(val_ds, batch_size=32, shuffle=False)

print("Sequence shape (per sample):", dataset[0][0].shape)   # (seq_len, 1)
print(f"Train: {len(train_ds)}, Val: {len(val_ds)}")


# ---------------------------------------------------------------------------
# 2. LSTM-based classifier
# ---------------------------------------------------------------------------
section("2. LSTM Model")


class SequenceClassifier(nn.Module):
    def __init__(self, input_size=1, hidden_size=32, num_layers=1, num_classes=2):
        super().__init__()
        self.lstm = nn.LSTM(
            input_size=input_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,   # input shape: (batch, seq_len, input_size)
        )
        self.fc = nn.Linear(hidden_size, num_classes)

    def forward(self, x):
        # lstm_out: (batch, seq_len, hidden_size) -- output at every timestep
        # h_n: (num_layers, batch, hidden_size) -- final hidden state
        lstm_out, (h_n, c_n) = self.lstm(x)

        # Use the final hidden state of the last layer for classification
        last_hidden = h_n[-1]              # (batch, hidden_size)
        logits = self.fc(last_hidden)      # (batch, num_classes)
        return logits


model = SequenceClassifier(input_size=1, hidden_size=32, num_layers=1, num_classes=2).to(device)
print(model)


# ---------------------------------------------------------------------------
# 3. Training loop (same pattern as modules 05-06)
# ---------------------------------------------------------------------------
section("3. Training")

criterion = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)


def train_one_epoch(model, loader):
    model.train()
    total_loss, correct, total = 0.0, 0, 0
    for x, y in loader:
        x, y = x.to(device), y.to(device)
        optimizer.zero_grad()
        logits = model(x)
        loss = criterion(logits, y)
        loss.backward()
        optimizer.step()

        total_loss += loss.item() * x.size(0)
        correct += (logits.argmax(1) == y).sum().item()
        total += x.size(0)
    return total_loss / total, correct / total


@torch.no_grad()
def evaluate(model, loader):
    model.eval()
    total_loss, correct, total = 0.0, 0, 0
    for x, y in loader:
        x, y = x.to(device), y.to(device)
        logits = model(x)
        loss = criterion(logits, y)
        total_loss += loss.item() * x.size(0)
        correct += (logits.argmax(1) == y).sum().item()
        total += x.size(0)
    return total_loss / total, correct / total


n_epochs = 15
for epoch in range(1, n_epochs + 1):
    train_loss, train_acc = train_one_epoch(model, train_loader)
    val_loss, val_acc = evaluate(model, val_loader)
    if epoch % 3 == 0 or epoch == 1:
        print(
            f"Epoch {epoch:2d}/{n_epochs} | "
            f"train_loss={train_loss:.4f} train_acc={train_acc:.3f} | "
            f"val_loss={val_loss:.4f} val_acc={val_acc:.3f}"
        )


if __name__ == "__main__":
    print("\nSwap nn.LSTM for nn.GRU to try a lighter-weight recurrent unit, or")
    print("stack multiple layers via num_layers=2+ for more capacity. For text,")
    print("replace the raw numeric input with an nn.Embedding layer first.")
