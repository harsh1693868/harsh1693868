"""
05 - The Full Training Loop
==============================
This module ties everything together: model, loss function, optimizer,
DataLoader, and the standard train/validate loop pattern you'll reuse in
almost every PyTorch project.

Run this file: python 05_training_loop/training_loop.py
"""

import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader, random_split


def section(title):
    print("\n" + "=" * 60)
    print(title)
    print("=" * 60)


# ---------------------------------------------------------------------------
# Setup: a toy binary classification dataset
# ---------------------------------------------------------------------------
section("Setup: Toy Classification Dataset")


class BlobDataset(Dataset):
    """Two Gaussian blobs -- a simple, linearly-separable binary classification task."""

    def __init__(self, n_samples=500):
        torch.manual_seed(0)
        n_per_class = n_samples // 2

        class0 = torch.randn(n_per_class, 2) + torch.tensor([-2.0, -2.0])
        class1 = torch.randn(n_per_class, 2) + torch.tensor([2.0, 2.0])

        self.x = torch.cat([class0, class1], dim=0)
        self.y = torch.cat([torch.zeros(n_per_class), torch.ones(n_per_class)]).long()

    def __len__(self):
        return len(self.x)

    def __getitem__(self, idx):
        return self.x[idx], self.y[idx]


dataset = BlobDataset(n_samples=500)
train_size = int(0.8 * len(dataset))
val_size = len(dataset) - train_size
train_ds, val_ds = random_split(dataset, [train_size, val_size])

train_loader = DataLoader(train_ds, batch_size=32, shuffle=True)
val_loader = DataLoader(val_ds, batch_size=32, shuffle=False)

print(f"Train samples: {len(train_ds)}, Val samples: {len(val_ds)}")


# ---------------------------------------------------------------------------
# Model
# ---------------------------------------------------------------------------
section("Model Definition")


class Classifier(nn.Module):
    def __init__(self):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(2, 16),
            nn.ReLU(),
            nn.Linear(16, 16),
            nn.ReLU(),
            nn.Linear(16, 2),   # 2 output logits, one per class
        )

    def forward(self, x):
        return self.net(x)


device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = Classifier().to(device)
print(model)
print("Using device:", device)


# ---------------------------------------------------------------------------
# Loss function and optimizer
# ---------------------------------------------------------------------------
section("Loss & Optimizer")

criterion = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(), lr=0.01)
print("Loss:", criterion)
print("Optimizer:", optimizer)


# ---------------------------------------------------------------------------
# Training + validation functions
# ---------------------------------------------------------------------------
section("Training Loop")


def train_one_epoch(model, loader, criterion, optimizer, device):
    model.train()  # enables dropout/batchnorm training behavior (no-op here, but good habit)
    total_loss, correct, total = 0.0, 0, 0

    for x, y in loader:
        x, y = x.to(device), y.to(device)

        optimizer.zero_grad()          # 1. clear old gradients
        logits = model(x)              # 2. forward pass
        loss = criterion(logits, y)    # 3. compute loss
        loss.backward()                # 4. backpropagate
        optimizer.step()               # 5. update weights

        total_loss += loss.item() * x.size(0)
        preds = logits.argmax(dim=1)
        correct += (preds == y).sum().item()
        total += x.size(0)

    return total_loss / total, correct / total


@torch.no_grad()
def evaluate(model, loader, criterion, device):
    model.eval()   # disables dropout/batchnorm training behavior
    total_loss, correct, total = 0.0, 0, 0

    for x, y in loader:
        x, y = x.to(device), y.to(device)
        logits = model(x)
        loss = criterion(logits, y)

        total_loss += loss.item() * x.size(0)
        preds = logits.argmax(dim=1)
        correct += (preds == y).sum().item()
        total += x.size(0)

    return total_loss / total, correct / total


n_epochs = 20
for epoch in range(1, n_epochs + 1):
    train_loss, train_acc = train_one_epoch(model, train_loader, criterion, optimizer, device)
    val_loss, val_acc = evaluate(model, val_loader, criterion, device)

    if epoch % 4 == 0 or epoch == 1:
        print(
            f"Epoch {epoch:2d}/{n_epochs} | "
            f"train_loss={train_loss:.4f} train_acc={train_acc:.3f} | "
            f"val_loss={val_loss:.4f} val_acc={val_acc:.3f}"
        )


if __name__ == "__main__":
    print("\nThis train/validate loop pattern -- zero_grad, forward, loss,")
    print("backward, step -- is the core of nearly every PyTorch training script.")
    print("Module 06 applies this same pattern to a real CNN on image data.")
