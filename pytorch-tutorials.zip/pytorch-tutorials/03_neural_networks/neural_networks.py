"""
03 - Neural Networks with nn.Module
=====================================
PyTorch models are built by subclassing torch.nn.Module. This module covers
defining layers, activation functions, the forward pass, and inspecting
parameters.

Run this file: python 03_neural_networks/neural_networks.py
"""

import torch
import torch.nn as nn


def section(title):
    print("\n" + "=" * 60)
    print(title)
    print("=" * 60)


# ---------------------------------------------------------------------------
# 1. A simple feed-forward network
# ---------------------------------------------------------------------------
section("1. Defining a Network")


class SimpleNet(nn.Module):
    """A basic 2-hidden-layer MLP for classification-style tasks."""

    def __init__(self, input_size=10, hidden_size=32, output_size=2):
        super().__init__()
        self.fc1 = nn.Linear(input_size, hidden_size)
        self.fc2 = nn.Linear(hidden_size, hidden_size)
        self.fc3 = nn.Linear(hidden_size, output_size)
        self.relu = nn.ReLU()

    def forward(self, x):
        x = self.relu(self.fc1(x))
        x = self.relu(self.fc2(x))
        x = self.fc3(x)   # no activation here -- raw logits, loss fn handles the rest
        return x


model = SimpleNet(input_size=10, hidden_size=32, output_size=2)
print(model)


# ---------------------------------------------------------------------------
# 2. Forward pass
# ---------------------------------------------------------------------------
section("2. Forward Pass")

dummy_input = torch.randn(4, 10)   # batch of 4 samples, 10 features each
output = model(dummy_input)
print("Input shape:", dummy_input.shape)
print("Output shape:", output.shape)
print("Output:\n", output)


# ---------------------------------------------------------------------------
# 3. Inspecting parameters
# ---------------------------------------------------------------------------
section("3. Model Parameters")

total_params = sum(p.numel() for p in model.parameters())
trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
print(f"Total parameters: {total_params}")
print(f"Trainable parameters: {trainable_params}")

for name, param in model.named_parameters():
    print(f"  {name:15s} shape={tuple(param.shape)}")


# ---------------------------------------------------------------------------
# 4. Using nn.Sequential for simpler stacks
# ---------------------------------------------------------------------------
section("4. nn.Sequential")

seq_model = nn.Sequential(
    nn.Linear(10, 32),
    nn.ReLU(),
    nn.Linear(32, 32),
    nn.ReLU(),
    nn.Linear(32, 2),
)
print(seq_model)
print("Output shape:", seq_model(dummy_input).shape)


# ---------------------------------------------------------------------------
# 5. Common activation functions
# ---------------------------------------------------------------------------
section("5. Activation Functions")

x = torch.linspace(-3, 3, 7)
print("Input:        ", x)
print("ReLU:         ", torch.relu(x))
print("Sigmoid:      ", torch.sigmoid(x))
print("Tanh:         ", torch.tanh(x))
print("Softmax(dim0):", torch.softmax(x, dim=0))


# ---------------------------------------------------------------------------
# 6. Common loss functions (quick preview -- more in module 05)
# ---------------------------------------------------------------------------
section("6. Loss Functions Preview")

logits = torch.randn(4, 2)          # 4 samples, 2 classes
targets = torch.tensor([0, 1, 1, 0])

criterion = nn.CrossEntropyLoss()
loss = criterion(logits, targets)
print("Cross-entropy loss:", loss.item())

mse = nn.MSELoss()
pred = torch.tensor([2.5, 0.0, 2.1])
true = torch.tensor([3.0, -0.5, 2.0])
print("MSE loss:", mse(pred, true).item())


if __name__ == "__main__":
    print("\nYou now know how to define layers, run a forward pass, and inspect")
    print("a model. Module 05 will show you the full training loop.")
