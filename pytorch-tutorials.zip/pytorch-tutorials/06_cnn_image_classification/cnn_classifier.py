"""
06 - CNNs for Image Classification
=====================================
Builds and trains a small Convolutional Neural Network on CIFAR-10, applying
the same train/validate pattern from module 05 to real image data.

NOTE: This downloads CIFAR-10 (~170 MB) on first run. Set `SUBSET_SIZE` lower
or `N_EPOCHS` lower if you just want a quick smoke-test.

Run this file: python 06_cnn_image_classification/cnn_classifier.py
"""

import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Subset
from torchvision import datasets, transforms


def section(title):
    print("\n" + "=" * 60)
    print(title)
    print("=" * 60)


device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Using device:", device)

# Keep this small by default so the tutorial runs quickly on a CPU.
# Increase for real training.
SUBSET_SIZE = 4000
N_EPOCHS = 5


# ---------------------------------------------------------------------------
# 1. Data
# ---------------------------------------------------------------------------
section("1. CIFAR-10 Data")

transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5)),
])

classes = ("plane", "car", "bird", "cat", "deer", "dog", "frog", "horse", "ship", "truck")

train_full = datasets.CIFAR10(root="./data", train=True, download=True, transform=transform)
test_full = datasets.CIFAR10(root="./data", train=False, download=True, transform=transform)

# Use a subset so the tutorial trains in a reasonable time on CPU
train_ds = Subset(train_full, range(min(SUBSET_SIZE, len(train_full))))
test_ds = Subset(test_full, range(min(1000, len(test_full))))

train_loader = DataLoader(train_ds, batch_size=64, shuffle=True)
test_loader = DataLoader(test_ds, batch_size=64, shuffle=False)

print(f"Training on {len(train_ds)} images, testing on {len(test_ds)} images")


# ---------------------------------------------------------------------------
# 2. CNN architecture
# ---------------------------------------------------------------------------
section("2. CNN Architecture")


class SimpleCNN(nn.Module):
    """A small CNN: Conv -> ReLU -> Pool, twice, then a classifier head."""

    def __init__(self, num_classes=10):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(3, 32, kernel_size=3, padding=1),   # (B, 32, 32, 32)
            nn.ReLU(),
            nn.MaxPool2d(2),                               # (B, 32, 16, 16)

            nn.Conv2d(32, 64, kernel_size=3, padding=1),   # (B, 64, 16, 16)
            nn.ReLU(),
            nn.MaxPool2d(2),                               # (B, 64, 8, 8)
        )
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(64 * 8 * 8, 128),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(128, num_classes),
        )

    def forward(self, x):
        x = self.features(x)
        x = self.classifier(x)
        return x


model = SimpleCNN(num_classes=10).to(device)
print(model)

n_params = sum(p.numel() for p in model.parameters())
print(f"Total parameters: {n_params:,}")


# ---------------------------------------------------------------------------
# 3. Training
# ---------------------------------------------------------------------------
section("3. Training")

criterion = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)


def train_one_epoch(model, loader):
    model.train()
    total_loss, correct, total = 0.0, 0, 0
    for images, labels in loader:
        images, labels = images.to(device), labels.to(device)

        optimizer.zero_grad()
        logits = model(images)
        loss = criterion(logits, labels)
        loss.backward()
        optimizer.step()

        total_loss += loss.item() * images.size(0)
        correct += (logits.argmax(1) == labels).sum().item()
        total += images.size(0)
    return total_loss / total, correct / total


@torch.no_grad()
def evaluate(model, loader):
    model.eval()
    total_loss, correct, total = 0.0, 0, 0
    for images, labels in loader:
        images, labels = images.to(device), labels.to(device)
        logits = model(images)
        loss = criterion(logits, labels)

        total_loss += loss.item() * images.size(0)
        correct += (logits.argmax(1) == labels).sum().item()
        total += images.size(0)
    return total_loss / total, correct / total


for epoch in range(1, N_EPOCHS + 1):
    train_loss, train_acc = train_one_epoch(model, train_loader)
    test_loss, test_acc = evaluate(model, test_loader)
    print(
        f"Epoch {epoch}/{N_EPOCHS} | "
        f"train_loss={train_loss:.4f} train_acc={train_acc:.3f} | "
        f"test_loss={test_loss:.4f} test_acc={test_acc:.3f}"
    )


# ---------------------------------------------------------------------------
# 4. Inspect a few predictions
# ---------------------------------------------------------------------------
section("4. Sample Predictions")

model.eval()
images, labels = next(iter(test_loader))
images, labels = images.to(device), labels.to(device)
with torch.no_grad():
    preds = model(images).argmax(1)

for i in range(5):
    print(f"True: {classes[labels[i]]:8s} | Predicted: {classes[preds[i]]:8s}")


if __name__ == "__main__":
    print("\nIncrease SUBSET_SIZE and N_EPOCHS at the top of this file, and use a")
    print("GPU, to push accuracy much higher. Module 07 shows a faster path:")
    print("fine-tuning a pretrained model instead of training from scratch.")
