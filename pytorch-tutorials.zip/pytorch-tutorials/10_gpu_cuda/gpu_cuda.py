"""
10 - GPU / CUDA Usage
========================
Covers device management: checking GPU availability, moving tensors and
models to the GPU, writing device-agnostic code, and a peek at mixed
precision training for speed.

Run this file: python 10_gpu_cuda/gpu_cuda.py
(Works fine on a CPU-only machine too -- it will just report no GPU found.)
"""

import time
import torch
import torch.nn as nn


def section(title):
    print("\n" + "=" * 60)
    print(title)
    print("=" * 60)


# ---------------------------------------------------------------------------
# 1. Checking for GPU availability
# ---------------------------------------------------------------------------
section("1. Checking for a GPU")

print("CUDA available:", torch.cuda.is_available())
if torch.cuda.is_available():
    print("GPU device name:", torch.cuda.get_device_name(0))
    print("Number of GPUs:", torch.cuda.device_count())
else:
    print("No GPU found -- running on CPU. Everything below still works, just slower.")

# The standard device-agnostic pattern used throughout this whole repo:
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Selected device:", device)


# ---------------------------------------------------------------------------
# 2. Moving tensors to a device
# ---------------------------------------------------------------------------
section("2. Moving Tensors")

x = torch.rand(3, 3)
print("Tensor device before:", x.device)

x = x.to(device)
print("Tensor device after .to(device):", x.device)

# IMPORTANT: operations between tensors on DIFFERENT devices will error.
y = torch.rand(3, 3)   # still on CPU
try:
    z = x + y.to("cpu") if device.type == "cpu" else x + y  # deliberately mismatched if on GPU
except RuntimeError as e:
    print("Expected error from device mismatch:", e)


# ---------------------------------------------------------------------------
# 3. Moving a whole model to a device
# ---------------------------------------------------------------------------
section("3. Moving a Model")


class TinyNet(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc = nn.Linear(10, 2)

    def forward(self, x):
        return self.fc(x)


model = TinyNet().to(device)   # moves ALL parameters and buffers to the device
print("Model parameters are on:", next(model.parameters()).device)

# Remember: inputs must be on the SAME device as the model
dummy_input = torch.randn(4, 10).to(device)
output = model(dummy_input)
print("Output device:", output.device)


# ---------------------------------------------------------------------------
# 4. Simple CPU vs GPU speed comparison (matrix multiply)
# ---------------------------------------------------------------------------
section("4. CPU vs GPU Speed Comparison")

size = 2000
a_cpu = torch.randn(size, size)
b_cpu = torch.randn(size, size)

start = time.time()
_ = a_cpu @ b_cpu
cpu_time = time.time() - start
print(f"CPU matmul ({size}x{size}): {cpu_time:.4f} s")

if torch.cuda.is_available():
    a_gpu = a_cpu.to(device)
    b_gpu = b_cpu.to(device)
    torch.cuda.synchronize()   # ensure previous ops finished before timing

    start = time.time()
    _ = a_gpu @ b_gpu
    torch.cuda.synchronize()   # wait for GPU op to actually finish
    gpu_time = time.time() - start
    print(f"GPU matmul ({size}x{size}): {gpu_time:.4f} s")
    print(f"Speedup: {cpu_time / gpu_time:.1f}x")
else:
    print("No GPU available to benchmark against.")


# ---------------------------------------------------------------------------
# 5. Mixed precision training (preview)
# ---------------------------------------------------------------------------
section("5. Mixed Precision Training (preview)")

print("""
On a CUDA GPU, you can speed up training and reduce memory usage with
automatic mixed precision (AMP). The pattern looks like this inside a
training loop:

    scaler = torch.cuda.amp.GradScaler()

    for x, y in loader:
        optimizer.zero_grad()
        with torch.autocast(device_type="cuda", dtype=torch.float16):
            output = model(x)
            loss = criterion(output, y)
        scaler.scale(loss).backward()
        scaler.step(optimizer)
        scaler.update()

This isn't run here since it requires an actual CUDA GPU to demonstrate
correctly, but it's a drop-in addition to the training loop from module 05.
""")


if __name__ == "__main__":
    print("Key habit: always write device-agnostic code with")
    print('  device = torch.device("cuda" if torch.cuda.is_available() else "cpu")')
    print("and call .to(device) on both your model and every batch of data.")
