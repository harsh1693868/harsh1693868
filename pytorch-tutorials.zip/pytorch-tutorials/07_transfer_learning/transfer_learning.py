"""
07 - Transfer Learning
========================
Instead of training a CNN from scratch, we can start from a model pretrained
on ImageNet (ResNet18) and adapt it to a new task. Two common strategies:

  1. Feature extraction: freeze the pretrained backbone, only train a new
     classifier head.
  2. Fine-tuning: unfreeze some/all backbone layers and train with a small
     learning rate.

This tutorial demonstrates both on a small CIFAR-10 subset (as a stand-in for
"your own dataset" -- swap in an ImageFolder dataset for real projects).

Run this file: python 07_transfer_learning/transfer_learning.py
"""

import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Subset
from torchvision import datasets, transforms, models


def section(title):
    print("\n" + "=" * 60)
    print(title)
    print("=" * 60)


device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Using device:", device)

SUBSET_SIZE = 2000
N_EPOCHS = 3


# ---------------------------------------------------------------------------
# 1. Data — resize to 224x224 to match ImageNet-pretrained expectations
# ---------------------------------------------------------------------------
section("1. Data (resized for ImageNet-pretrained models)")

# These normalization stats match what ResNet was originally trained on.
imagenet_mean = [0.485, 0.456, 0.406]
imagenet_std = [0.229, 0.224, 0.225]

transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize(imagenet_mean, imagenet_std),
])

train_full = datasets.CIFAR10(root="./data", train=True, download=True, transform=transform)
test_full = datasets.CIFAR10(root="./data", train=False, download=True, transform=transform)

train_ds = Subset(train_full, range(min(SUBSET_SIZE, len(train_full))))
test_ds = Subset(test_full, range(min(500, len(test_full))))

train_loader = DataLoader(train_ds, batch_size=32, shuffle=True)
test_loader = DataLoader(test_ds, batch_size=32, shuffle=False)

print(f"Training on {len(train_ds)} images, testing on {len(test_ds)} images")


# ---------------------------------------------------------------------------
# 2. Strategy A -- Feature extraction (freeze backbone)
# ---------------------------------------------------------------------------
section("2. Strategy A: Feature Extraction")

# Loads ResNet18 pretrained on ImageNet. `weights` API is the modern
# torchvision way (replaces the older `pretrained=True` argument).
weights = models.ResNet18_Weights.DEFAULT
model = models.resnet18(weights=weights)

# Freeze every parameter in the pretrained backbone
for param in model.parameters():
    param.requires_grad = False

# Replace the final fully-connected layer with a new, trainable one for
# our 10 CIFAR-10 classes. New layers are trainable by default.
num_features = model.fc.in_features
model.fc = nn.Linear(num_features, 10)

model = model.to(device)

trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
frozen = sum(p.numel() for p in model.parameters() if not p.requires_grad)
print(f"Trainable parameters: {trainable:,} | Frozen parameters: {frozen:,}")

criterion = nn.CrossEntropyLoss()
# Only pass parameters that require gradients to the optimizer
optimizer = torch.optim.Adam(filter(lambda p: p.requires_grad, model.parameters()), lr=1e-3)


def train_one_epoch(model, loader):
    model.train()
    total_loss, correct, total = 0.0, 0, 0
    for images, labels in loader:
        images, labels = images.to(device), labels.to(device)
        optimizer.zero_grad()
        logits = model(images)
        loss = criterion(logits, labels)
        loss.backward()
        optimizer.step()

        total_loss += loss.item() * images.size(0)
        correct += (logits.argmax(1) == labels).sum().item()
        total += images.size(0)
    return total_loss / total, correct / total


@torch.no_grad()
def evaluate(model, loader):
    model.eval()
    total_loss, correct, total = 0.0, 0, 0
    for images, labels in loader:
        images, labels = images.to(device), labels.to(device)
        logits = model(images)
        loss = criterion(logits, labels)
        total_loss += loss.item() * images.size(0)
        correct += (logits.argmax(1) == labels).sum().item()
        total += images.size(0)
    return total_loss / total, correct / total


print("\nTraining classifier head only (backbone frozen)...")
for epoch in range(1, N_EPOCHS + 1):
    train_loss, train_acc = train_one_epoch(model, train_loader)
    test_loss, test_acc = evaluate(model, test_loader)
    print(
        f"Epoch {epoch}/{N_EPOCHS} | "
        f"train_loss={train_loss:.4f} train_acc={train_acc:.3f} | "
        f"test_loss={test_loss:.4f} test_acc={test_acc:.3f}"
    )


# ---------------------------------------------------------------------------
# 3. Strategy B -- Fine-tuning (unfreeze last block + head)
# ---------------------------------------------------------------------------
section("3. Strategy B: Fine-Tuning (unfreeze last residual block)")

# Unfreeze the last block of ResNet18 ("layer4") for fine-tuning with a
# smaller learning rate, while keeping earlier layers (generic features
# like edges/textures) frozen.
for param in model.layer4.parameters():
    param.requires_grad = True

trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
print(f"Trainable parameters after unfreezing layer4: {trainable:,}")

# Use a smaller learning rate for fine-tuning to avoid destroying pretrained weights
optimizer = torch.optim.Adam(filter(lambda p: p.requires_grad, model.parameters()), lr=1e-4)

print("\nFine-tuning layer4 + classifier head...")
for epoch in range(1, N_EPOCHS + 1):
    train_loss, train_acc = train_one_epoch(model, train_loader)
    test_loss, test_acc = evaluate(model, test_loader)
    print(
        f"Epoch {epoch}/{N_EPOCHS} | "
        f"train_loss={train_loss:.4f} train_acc={train_acc:.3f} | "
        f"test_loss={test_loss:.4f} test_acc={test_acc:.3f}"
    )


if __name__ == "__main__":
    print("\nKey takeaway: freeze what's generic (early layers), train what's")
    print("task-specific (the head, and optionally later layers). This gets you")
    print("strong results with far less data and compute than training from scratch.")
