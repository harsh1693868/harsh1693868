# PyTorch Tutorials — A Complete Beginner-to-Intermediate Series

A hands-on, code-first PyTorch tutorial series. Each module is a self-contained,
runnable Python script with heavy inline comments explaining *why*, not just *what*.
Designed for learning by running and tweaking code, and to double as a portfolio
project on GitHub.

## Structure

| # | Module | What you'll learn |
|---|--------|--------------------|
| 01 | [Tensors](01_tensors/tensors.py) | Creating tensors, shapes, dtypes, indexing, reshaping, broadcasting, tensor-NumPy interop |
| 02 | [Autograd](02_autograd/autograd.py) | Automatic differentiation, `requires_grad`, `.backward()`, gradient accumulation, `no_grad()` |
| 03 | [Neural Networks](03_neural_networks/neural_networks.py) | `nn.Module`, layers, activation functions, forward pass, parameter inspection |
| 04 | [Datasets & DataLoaders](04_datasets_dataloaders/datasets_dataloaders.py) | `Dataset`, `DataLoader`, batching, shuffling, `transforms` |
| 05 | [Training Loop](05_training_loop/training_loop.py) | Loss functions, optimizers, the full train/validate loop, tracking metrics |
| 06 | [CNNs for Image Classification](06_cnn_image_classification/cnn_classifier.py) | Convolutional layers, pooling, training a CNN on CIFAR-10 |
| 07 | [Transfer Learning](07_transfer_learning/transfer_learning.py) | Using pretrained models (ResNet), feature extraction vs. fine-tuning |
| 08 | [RNN / LSTM](08_rnn_lstm/rnn_lstm.py) | Sequence modeling, `nn.LSTM`, sequence classification |
| 09 | [Saving & Loading Models](09_saving_loading_models/saving_loading.py) | `state_dict`, checkpoints, resuming training, exporting for inference |
| 10 | [GPU / CUDA](10_gpu_cuda/gpu_cuda.py) | Device management, moving tensors/models to GPU, mixed precision basics |
| 11 | [Custom Datasets & Augmentation](11_custom_datasets_augmentation/custom_datasets.py) | Writing a custom `Dataset` class, image augmentation with `torchvision.transforms` |

## Getting Started

```bash
git clone https://github.com/<your-username>/pytorch-tutorials.git
cd pytorch-tutorials
pip install -r requirements.txt
```

Then run any module directly, e.g.:

```bash
python 01_tensors/tensors.py
```

Each script prints output to the console so you can see results as you go. Scripts
that train models (06, 07, 08) will download small public datasets (CIFAR-10, IMDB-style
synthetic sequences) automatically via `torchvision`/`torch` on first run.

## Requirements

- Python 3.9+
- PyTorch 2.x
- torchvision
- (optional) CUDA-capable GPU for faster training in modules 06–08, 10

See `requirements.txt` for exact packages.

## Suggested Learning Path

1. Start with **01–03** to get comfortable with tensors, autograd, and building a network.
2. Move to **04–05** to understand how real training loops are structured.
3. Apply that knowledge in **06–08** with real architectures (CNN, pretrained ResNet, LSTM).
4. Finish with **09–11** for practical skills you'll need in any real project: checkpointing,
   GPU usage, and writing your own datasets.

## License

MIT — feel free to fork, use, and adapt for your own learning or teaching.

## Author

Maintained as a personal learning + portfolio project. Contributions and issues welcome.
